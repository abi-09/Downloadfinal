//
//  HomeView.swift
//  Trail Tales

import SwiftUI
import MapKit
import CoreLocation
import Combine


struct HomeView: View {
    @EnvironmentObject var mapVM : MapViewModel
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @State var showAlbum = false
    
    @GestureState var isLongPressing = false
    
    var longPressGesture: some Gesture {
        SpatialTapGesture()
            .onEnded { value in
                print(value.location)
            }
    }
        
    var body: some View {
        
        GeometryReader { reader in
            ZStack {
                
                MapReader { reader in
                    Map(position: $mapVM.position) {
                        UserAnnotation()

                        
                        ForEach (currentUser.user.albums, id :\.self) { album in
                            
                            
                            Annotation(
                                "",
                                coordinate: CLLocationCoordinate2D(latitude: album.lat, longitude: album.lng),
                                anchor : .bottom
                            ) {
                                MapAlbumButton(album: album, showAlbum: $showAlbum)
                            }
                        }

                    }
                    .onChange(of: mapVM.userLocation) { _, newLocation in
                        if mapVM.shouldRecenterMap {
                            mapVM.updateRegion(with: newLocation)
                            mapVM.shouldRecenterMap = false
                        }
                    }
                    .ignoresSafeArea()
                    .overlay(
                        Color.black.opacity(currentUser.showSideMenu ? 0.5 : 0)
                            .edgesIgnoringSafeArea(.all)
                            .onTapGesture {
                                withAnimation {
                                    currentUser.showSideMenu = false
                                }
                            }
                    )
                    .mapStyle(.standard(pointsOfInterest: .excludingAll))
                    .onTapGesture(perform: { screenCoord in
                        if let tappedLocation = reader.convert(screenCoord, from: .local) {
                            print(tappedLocation)

                            let (closestAlbum, isExistingAlbum) = currentUser.closestAlbum(to: CLLocation(latitude: tappedLocation.latitude, longitude: tappedLocation.longitude), minDistanceMiles: 1)
                            
                            currentUser.selectedAlbum = closestAlbum

                            if isExistingAlbum {
                                showAlbum = true
                            } else {
                                currentUser.showNewEntry = true
                                print("Showing new entry")
                            }
                        }
                    })
                }
                .sheet(isPresented: $showAlbum, content: {
                    if let album = currentUser.selectedAlbum {
                        AlbumView(album : album)
                    }
                })
                .overlay {
                    Color(currentUser.showSearchMenu ? .black : .clear).opacity(0.5).onTapGesture {
                        currentUser.showSearchMenu = false
                    }
                    .edgesIgnoringSafeArea(.all)

                }
                
            
                
                MapOverlayButtons()
                
                
                ProfileMenuView(showProfile: $currentUser.showSideMenu)
                    .trailingEdgeSheet(isPresented: currentUser.showSideMenu)

                MapSearchView()
                    .topDownSheet(isPresented: currentUser.showSearchMenu)
            }
        }
    }
}

struct MapSearchView : View {
    @EnvironmentObject var mapVM: MapViewModel
    @EnvironmentObject var currentUser: CurrentUserViewModel
    
    @State var mapQuery = ""
    @State private var searchResults = [MKMapItem]()

    
    func performSearch(query: String) {
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = query
        
        let search = MKLocalSearch(request: searchRequest)
        search.start { (response, error) in
            guard let response = response else {
                print("Error: \(error?.localizedDescription ?? "Unknown error").")
                return
            }
            
            self.searchResults = response.mapItems
        }
    }

    func selectLocation(_ mapItem: MKMapItem) {
        if let location = mapItem.placemark.location {
            mapVM.updateRegion(with: location)
        }
        currentUser.showSearchMenu = false
        hideKeyboard()
    }
    
    var body: some View {
        
        VStack {
            VStack {
                TextField("", text: $mapQuery, prompt: Text(verbatim: "Search..")
                    .font(.custom("Nunito Sans", size: 14))
                    .foregroundColor(.secondary))
                    .padding(.leading, 16)
                    .padding(.vertical, 13)
                    .foregroundColor(.primary)
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .inset(by: 0.5)
                            .stroke(Color(red: 0.07, green: 0.07, blue: 0.07).opacity(0.2), lineWidth: 1)
                    )
                    .background(.thinMaterial)
                    .cornerRadius(4)
                    .padding()
                    .padding(.top, 60)
                    .onChange(of: mapQuery) { _, newValue in
                        performSearch(query: newValue)
                    }
                
                ForEach(searchResults, id : \.self) { result in
                    
                    Button(action: {
                        selectLocation(result)

                    }, label: {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(result.name ?? "Unknown place")
                                    .fontWeight(.medium)
                                Text(result.placemark.title ?? "")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                    .multilineTextAlignment(.leading)
                            }
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")

                        }
                        .foregroundColor(.primary)

                    })
                    .padding(.horizontal)
                    .padding(.vertical, 5)

                    Divider()
                }

            }
            .background(.regularMaterial)
            .cornerRadius(10, corners: [.bottomLeft, .bottomRight])
            .edgesIgnoringSafeArea(.top)
            
            Spacer()
        }
    }
}



struct MapAlbumButton : View {
    var album : Album
    @Binding var showAlbum : Bool
    
    var body: some View {
        VStack {
            HStack {
                if album.coverImage == "" {
                    Text("\(album.dateCreated.toCustomStringFormat())")
                        .foregroundColor(.black)
                        .font(.system(size: 10))
                        .scaledToFill()
                        .frame(width : 80, height :50)
                        .cornerRadius(10)
                        .clipped()
                } else {
                    CachedAsyncImageView(urlString: album.coverImage)
                        .scaledToFill()
                        .frame(width : 80, height :50)
                        .cornerRadius(10)
                        .clipped()
                }

            }
            .padding(2)
            .background(.white)
            .cornerRadius(10)
            .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            Image(systemName: "mappin")
                .font(.system(size: 24))
                .foregroundColor(.indigo)

        }

    }
}


struct MapOverlayButtons : View {
    @EnvironmentObject var mapVM : MapViewModel
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    var body: some View {
        HStack {
            
            Spacer()
                .navigationTitle("")
                .navigationBarHidden(true)
            
            VStack(alignment :.trailing, spacing : 0) {
                VStack {
                    
                    Divider()
                    
                    Button(action: {
                        mapVM.updateRegion(with: mapVM.userLocation)
                    }) {
                        Image(systemName: "location.fill")
                            .foregroundColor(.white)
                            .padding()
                        
                    }
                    
                    Divider()
                    
                    Button(action: {
                        currentUser.showSideMenu = true
                    }, label: {
                        Image(systemName: "person.fill")
                            .foregroundColor(.white)
                            .padding()
                    })
                    
                    Divider()
                    
                    Button(action: {
                        currentUser.showSearchMenu = true
                    }, label: {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                            .padding()
                    })
                }
                .background{
                    Color.black.opacity(0.9).cornerRadius(20.0)
                }
                .padding()
                .frame(width : 80)



                Spacer()
            

            }

        }
    }
}



#Preview {
    HomeView()
        .environmentObject(MapViewModel())
        .environmentObject(CurrentUserViewModel())

}
