//
//  AlbumsView.swift
//  Trail Tales


import SwiftUI

struct AlbumsListView: View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    
    var body: some View {
        VStack {
            
            HStack {
                Text("Albums")
                    .fontWeight(.bold)
                    .font(.title)
                
                Spacer()
            }
            .padding()
            
            
            if currentUser.user.albums.count > 0 {
                ScrollView {
                    ForEach(currentUser.user.albums, id :\.self) { album in
                        NavigationLink {
                            AlbumView(album : album)
                        } label: {
                            AlbumPreview(album : album)
                        }
                    }
                }
                
            } else {
                VStack {
                    Spacer()
                    Image("no-albums")
                        .resizable()
                        .scaledToFit()
                        .frame(height : 200)
                    
                    Text("No albums yet")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    Spacer()
                }
            }

        }
        .background(.regularMaterial)
    }
}



struct AlbumPreview : View {
    var album : Album
    
    var body: some View {
        VStack(spacing : 0) {
            if album.coverImage != "" {
                CachedAsyncImageView(urlString: album.coverImage)
                    .scaledToFill()
                    .frame(height : 200)
                    .cornerRadius(5)
            }

            
            HStack {
                Text(album.description)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .padding()
                
                Spacer()

            }
            .foregroundColor(.primary)
            
            Divider()

            HStack {
                
                Image(systemName: "mappin")
                Text("\(album.locationString)")
                
                Spacer()
                
                Image(systemName: "chevron.right")
            }
            .font(.system(size: 12))
            .foregroundColor(.secondary)
            .padding()


        }
        .padding(5)
        .background(.regularMaterial)
        .cornerRadius(5)
        .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x: 0, y :5)
        .padding()

    }
}


#Preview {
    AlbumsListView()
}
