//
//  UserAlbumView.swift
//  Trail Tales
//
//  Created by Adrian Martushev on 4/12/24.
//

import SwiftUI



struct UserAlbumView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var mapVM : MapViewModel
    @EnvironmentObject var currentUser : CurrentUserViewModel

    @State var showJournalEntry = false
    @State var showNewJournalEntry = false
    @State var showDeleteAlert = false
    @State var locationString = "Fetching location.."
    
    var album : Album
    
    var body: some View {
        VStack {
            HStack {
                
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                }, label: {
                    Image(systemName: "chevron.left")
                })
                .foregroundColor(.primary)
                
                
                Text("\(locationString)")
                    .fontWeight(.bold)
                    .font(.headline)
                    .onAppear {
                        mapVM.reverseGeocodeLocation(latitude: album.lat, longitude: album.lng) { location in
                            if let locString = location {
                                locationString = locString
                            }
                        }
                    }
                
                Spacer()
                
            }
            .padding()
            .navigationTitle("")
            .navigationBarHidden(true)
            
            ScrollView {
                
                ForEach(album.journalEntries, id :\.self) { journal in
                    if journal.isPublic {
                        Button(action: {
                            showJournalEntry = true
                            currentUser.journalToDisplay = journal
                        }, label: {
                            JournalEntryPreview(journal : journal)
                        })
                    }

                }
            }

        }
        .sheet(isPresented: $showJournalEntry, content: {
            UserJournalEntryView()
        })
        .background(.regularMaterial)

    }
}




#Preview {
    UserAlbumView(album : empty_album)
}
