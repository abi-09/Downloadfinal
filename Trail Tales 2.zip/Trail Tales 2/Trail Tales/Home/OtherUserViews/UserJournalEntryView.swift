//
//  UserJournalEntryView.swift
//  Trail Tales
//
//  Created by Adrian Martushev on 4/12/24.
//

import SwiftUI


struct UserJournalEntryView : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    @EnvironmentObject var mapVM : MapViewModel
    @EnvironmentObject var currentUser : CurrentUserViewModel

    @State var locationString : String = "Fetching location"
    @State private var showShareSheet = false

    var body: some View {
        VStack(spacing : 0) {
            
            HStack {
                
                VStack(alignment : .leading, spacing : 8) {
                    HStack {
                        Image(systemName: "mappin")
                        Text("\(locationString)")
                    }
                    HStack {
                        Image(systemName: "clock")
                        Text("\(currentUser.journalToDisplay.date.toCustomStringFormat())")
                    }
                    HStack {
                        Image(systemName: "globe.central.south.asia.fill")
                        Text("Public")
                    }
                }
                .onAppear {
                    mapVM.reverseGeocodeLocation(latitude: currentUser.journalToDisplay.lat, longitude: currentUser.journalToDisplay.lng) { str in
                        if let location = str {
                            self.locationString = location
                        }
                    }
                }
                
                Spacer()
                

            }
            .font(.system(size: 12))
            .foregroundColor(.secondary)
            .padding(.vertical)
            
            Divider()
            
            if currentUser.journalToDisplay.image != "" {
                CachedAsyncImageView(urlString: currentUser.journalToDisplay.image)
                    .scaledToFill()
                    .frame(height : 200)
                    .cornerRadius(5)
            }
            
            ScrollView {
                VStack(alignment : .leading) {
                    HStack {
                        Text(currentUser.journalToDisplay.content)
                            .lineLimit(nil)
                            .multilineTextAlignment(.leading)
                            .padding()
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    


                }
            }
                        
            Spacer()

        }
        .padding(5)
        .padding()
    }
}

//#Preview {
//    UserJournalEntryView()
//}
