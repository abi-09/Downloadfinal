//
//  UserProfileView.swift
//  Trail Tales
//
//  Created by Adrian Martushev on 4/12/24.
//

import SwiftUI

struct UserProfileView : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @State var user : User
    @State var fetchingAlbums : Bool = true
    
    var body: some View {
        VStack {
            
            HStack {
                
                Button(action: {
                    currentUser.showUserProfile = false
                    self.presentationMode.wrappedValue.dismiss()

                }, label: {
                    Image(systemName : "chevron.left")
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                })

                Text("\(getFirstName(user.name))'s Profile")
                    .font(.title)
                    .fontWeight(.semibold)
                
                Spacer()
                
                if user.id == currentUser.currentUserID {
                    
                    NavigationLink {
                        ProfileSettingsView()
                    } label: {
                        
                        Image(systemName: "gear")
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                    }
                }


            }
            .padding()
            .navigationTitle("")
            .navigationBarHidden(true)

            
            ScrollView {
                VStack {
                    HStack  {
                        
                        ProfilePhotoOrInitials(profilePhoto: user.profilePhoto, fullName: user.name, radius: 80, fontSize: 40)
                            .padding(.trailing)
                            .id(currentUser.refreshID)

                        
                        VStack(alignment : .leading, spacing : 8) {
                            Text(user.name)
                                .font(.title2)
                                .foregroundColor(.primary)
                            
                            HStack {
                                Image(systemName: "clock")
                                Text("Joined \(user.dateJoined.toCustomStringFormat())")
                            }
                            .foregroundColor(.secondary)
                            .font(.system(size: 12))
                            
                            HStack {
                                Image(systemName: "photo")
                                Text("\(user.albums.count) albums")
                            }
                            .foregroundColor(.secondary)
                            .font(.system(size: 12))
                        }
                        
                        Spacer()
                        
                        
                    }
                    .padding()
                    .cornerRadius(5)
                    
                    Divider()
                    
                    if fetchingAlbums {
                        Spacer()
                        ProgressView("Fetching albums..")
                        Spacer()
                        
                    } else {
                        ForEach(user.albums, id :\.self) { album in
                            if album.journalEntries.count > 0 {
                                NavigationLink {
                                    UserAlbumView(album : album)
                                } label: {
                                    AlbumPreview(album: album)
                                }
                            }
                        }
                    }


                    Spacer()
                }
            }
        }
        .background(.regularMaterial)
        .onAppear(perform: {
            currentUser.fetchPublicUserAlbums(of: user.id) { albums in
                user.albums = albums
                self.fetchingAlbums = false
                print("Fetched albums for user: \(user.id), count : \(albums.count)")
            }
        })
    }
}



struct CurrentUserProfileView : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    
    var body: some View {
        VStack {
            
            HStack {
                
                Button(action: {
                    currentUser.showUserProfile = false

                }, label: {
                    Image(systemName : "chevron.left")
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                })

                Text("Your profile")
                    .font(.title)
                    .fontWeight(.semibold)
                
                Spacer()
                
                NavigationLink {
                    ProfileSettingsView()
                } label: {
                    
                    Image(systemName: "gear")
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                }


            }
            .padding()
            .navigationTitle("")
            .navigationBarHidden(true)

            
            ScrollView {
                VStack {
                    HStack  {
                        
                        ProfilePhotoOrInitials(profilePhoto: currentUser.user.profilePhoto, fullName: currentUser.user.name, radius: 80, fontSize: 40)
                            .padding(.trailing)
                            .id(currentUser.refreshID)

                        VStack(alignment : .leading, spacing : 8) {
                            Text(currentUser.user.name)
                                .font(.title2)
                                .foregroundColor(.primary)
                            
                            HStack {
                                Image(systemName: "clock")
                                Text("Joined \(currentUser.user.dateJoined.toCustomStringFormat())")
                            }
                            .foregroundColor(.secondary)
                            .font(.system(size: 12))
                            
                            HStack {
                                Image(systemName: "photo")
                                Text("\(currentUser.user.albums.count) albums")
                            }
                            .foregroundColor(.secondary)
                            .font(.system(size: 12))
                        }
                        
                        Spacer()
                        
                        
                    }
                    .padding()
                    .cornerRadius(5)
                    
                    Divider()
                    
                    ForEach(currentUser.user.albums, id :\.self) { album in
                        AlbumPreview(album: album)
                    }


                    Spacer()
                }
            }
        }
        .background(.regularMaterial)

    }
}

#Preview {
    UserProfileView(user : empty_user)
}
