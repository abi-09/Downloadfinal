//
//  ProfileSettingsView.swift
//  Trail Tales

import SwiftUI


struct ProfileSettingsView : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @State var isShowingSave = false
    @State private var buttonOpacity: Double = 0

    
    
    var body: some View {
        VStack {
            
            HStack {
                
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                }, label: {
                    Image(systemName : "chevron.left")
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                })


                Text("Your account")
                    .font(.title)
                    .fontWeight(.semibold)
                Spacer()
            }
            .padding()
            .navigationTitle("")
            .navigationBarHidden(true)

            VStack {
                HStack  {
                    ProfilePhotoButton()
                        .shadow(radius: 10, x:0, y:5)

                    VStack(alignment : .leading, spacing : 8) {
                        Text(currentUser.user.name)
                            .font(.title2)
                            .foregroundColor(.primary)
                        
                        HStack {
                            Image(systemName: "clock")
                            Text("Joined \(currentUser.user.dateJoined.toCustomStringFormat())")
                        }
                        .foregroundColor(.secondary)
                        .font(.system(size: 12))
                        
                        HStack {
                            Image(systemName: "photo")
                            Text("\(currentUser.user.albums.count) journal entries")
                        }
                        .foregroundColor(.secondary)
                        .font(.system(size: 12))
                    }
                    
                    Spacer()
                    
                    
                }
                .padding()
                .cornerRadius(5)
                
                Divider()
                    .padding(.horizontal)
                
                VStack {
                    
                    HStack {
                        Text("Edit profile")
                            .font(.title2)
                            .foregroundColor(.primary)
                        
                        Spacer()
                        if isShowingSave {
                            Button(action: {
                                currentUser.updateUser(data: ["name" : currentUser.user.name])
                                withAnimation(.easeIn(duration: 1.0)) {
                                    buttonOpacity = 0.0
                                }
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                                    isShowingSave = false
                                }
                            }, label: {
                                HStack {
                                    Text("Save")
                                        .foregroundColor(.primary)
                                        .padding(.horizontal, 12)
                                        .padding(.vertical, 8)
                                }
                                .background(.indigo)
                                .cornerRadius(8)
                            })
                            .opacity(buttonOpacity) 
                            .onAppear {
                                withAnimation(.easeIn(duration: 1.0)) {
                                    buttonOpacity = 1.0
                                }
                            }
                        }
                    }
                    .frame(height : 30)
                    .padding(.top, 24)
                    
                    
                    AccountCreationField(text: $currentUser.user.name, title: "Name", placeholder: "Jane")
                        .onChange(of: currentUser.user.name) { oldValue, newValue in
                            withAnimation {
                                isShowingSave = true
                            }
                        }
                    
                    Spacer()
                    
                    Button(action: {
                        //Sign out and dismiss all views back to root
                        currentUser.signOut()
                        self.presentationMode.wrappedValue.dismiss()
                        currentUser.showSideMenu = false
                        currentUser.showUserProfile = false

                    }, label: {
                        HStack {
                            Spacer()
                            Text("Logout")
                                .foregroundColor(.primary)
                            Spacer()

                        }
                        .frame(height : 50)
                        .background(.indigo)

                        .cornerRadius(8)
                    })
                }
                .padding(.horizontal)


            }
        }
        .background(.regularMaterial)
    }
}

#Preview {
    ProfileSettingsView()
        .environmentObject(CurrentUserViewModel())
}
