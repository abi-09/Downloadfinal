//
//  JournalEntryView.swift
//  Trail Tales

import SwiftUI


struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    var applicationActivities: [UIActivity]? = nil

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}


struct JournalEntryView : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var currentUser : CurrentUserViewModel
    @EnvironmentObject var mapVM : MapViewModel

    var albumID : String
    @State var journal : JournalEntry
    
    @State var locationString : String = "Fetching location"
    @State private var showShareSheet = false
    @State private var showDeleteAlert = false
    @State private var isEditing = false
    
    @State var isShowingImagePicker = false
    @State var selectedImage : UIImage?
    @State var imageURL = ""
    
    var body: some View {
        VStack(spacing : 0) {
            
            HStack {
                
                VStack(alignment : .leading, spacing : 8) {
                    HStack {
                        Image(systemName: "mappin") //create map pin
                        Text("\(locationString)") // attach to location
                    }
                    HStack {
                        Image(systemName: "clock")
                        Text("\(journal.date.toCustomStringFormat())")
                    }
                    
                    HStack {
                        Image(systemName: "globe.central.south.asia.fill")
                        Text(journal.isPublic ? "Public" : "Private")
                        Spacer()
                        if isEditing {
                            CustomToggleView(isOn: $journal.isPublic, title: "")
                        }
                    }
                    .frame(width : 120)

                }
                .onAppear {
                    mapVM.reverseGeocodeLocation(latitude: journal.lat, longitude: journal.lng) { str in
                        if let location = str {
                            self.locationString = location
                        }
                    }
                }
                
                Spacer()
                
                if isEditing {
                    Button(action: {
                        currentUser.updateJournalEntry(albumID: albumID, journalID: journal.id, newImageURL: journal.image, newContent: journal.content, isPublic: journal.isPublic) { success, error in
                            if success {
                                print("Update successful")
                                isEditing = false
                            } else {
                                print("Error updating journal entry: \(error?.localizedDescription ?? "Unknown error")")
                            }
                        }
                    }, label: {
                        Text("Save")
                            .frame(width : 60, height : 24)
                            .background(.indigo)
                            .cornerRadius(5)
                            .foregroundColor(.white)
                    })
                }
                

            }
            .font(.system(size: 12))
            .foregroundColor(.secondary)
            .padding(.vertical)
            
            Divider()
  

            VStack {
                if journal.image != "" {
                    ZStack {
                        CachedAsyncImageView(urlString: journal.image)
                            .scaledToFill()
                            .frame(height : 200)
                            .cornerRadius(5)
                            .id(journal.image)
                            .allowsHitTesting(false) // This view will not block touch events

                        if isEditing {
                            Button {
                                isShowingImagePicker = true
                            } label: {
                                Image(systemName: "camera")
                                    .font(.system(size: 24))
                                    .foregroundColor(.white)
                                    .background {
                                        Circle()
                                            .frame(width : 60, height : 60)
                                            .foregroundColor(.black.opacity(0.3))
                                    }
                            }
                            .sheet(isPresented: $isShowingImagePicker) {
                                ImagePicker(image: $selectedImage)
                                    .edgesIgnoringSafeArea(.bottom)
                            }
                            .onChange(of: isShowingImagePicker) { oldValue, newValue in
                                if !newValue { // When the sheet is dismissed
                                    if let selectedImage = selectedImage {
                                        currentUser.uploadImage(selectedImage: selectedImage) { uploadedImageURL in
                                            if let image = uploadedImageURL {
                                                journal.image = image
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .frame(height : 200)

                }
                
                HStack {

                    Spacer()

                    Button {
                        isEditing.toggle()
                    } label: {
                        Image(systemName: "square.and.pencil")
                            .foregroundColor(.primary)
                    }
                    .padding(.trailing)


                    Button {
                        showDeleteAlert = true
                    } label: {
                        Image(systemName: "trash")
                            .foregroundColor(.primary)
                    }
                    .padding(.trailing)
                    .alert(isPresented: $showDeleteAlert) {
                        Alert(
                            title: Text("Confirm Deletion"),
                            message: Text("Are you sure you want to delete this journal entry? This action cannot be undone."),
                            primaryButton: .destructive(Text("Delete")) {
                                currentUser.deleteJournalEntry(albumID: albumID, journalID: journal.id) { success, error in
                                    if success {
                                        presentationMode.wrappedValue.dismiss()
                                    } else {
                                        print("Error: \(error?.localizedDescription ?? "Unknown error")")
                                    }
                                }
                            },
                            secondaryButton: .cancel()
                        )
                    }

                    Button {
                        self.showShareSheet = true

                    } label: {
                        Image(systemName: "arrowshape.turn.up.forward.fill")
                            .foregroundColor(.primary)
                    }
                    .sheet(isPresented: $showShareSheet) {
                        ShareSheet(activityItems: [URL(string: self.journal.image)!, journal.content])
                    }
                }
                .padding()

                if isEditing {
                    TextEditor(text: $journal.content)
                        .multilineTextAlignment(.leading)
                        .padding()
                        .frame(minHeight: 100)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(.indigo, lineWidth: 1)
                        )
                        .foregroundColor(.primary)

                } else {
                    HStack {
                        Text(journal.content)
                            .lineLimit(nil)
                            .multilineTextAlignment(.leading)
                            .padding()
                            .foregroundColor(.primary)
                        
                        Spacer()
                    }
                }
            }
            
            Spacer()
        

        }
        .padding(15)
        .onTapGesture {
            hideKeyboard()
        }
    }
}

//#Preview {
//    JournalEntryView()
//}
