//
//  SearchFriendsView.swift
//  Trail Tales


import SwiftUI

struct SearchFriendsView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @State var searchResults : [User] = []
    
    @State var query : String = ""
    
    
    var body: some View {
        VStack {

            
            VStack {
                HStack {
                    Button(action: {
                        self.presentationMode.wrappedValue.dismiss()
                    }, label: {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    })
                    .foregroundColor(.primary)

                    Spacer()
                }
                .padding(.bottom)
                .navigationTitle("")
                .navigationBarHidden(true)
                
                AccountCreationField(text: $query, title: "Search People", placeholder: "Search") // search friends name
                
                ScrollView {
                    VStack(spacing: 8) {
                        ForEach(searchResults) { user in
                            if user.id != currentUser.currentUserID { //checks to see if id searched matches user id
                                UserSearchResult(user: user)
                            }
                        }
                    }
                    .padding(.vertical)
                }


                Spacer()
            }
            .padding()
        
            
        }
        .background(.regularMaterial)
        .onChange(of: query) { _, newValue in
            // Filter users based on the search query
            searchResults = currentUser.allUsers.filter { $0.name.lowercased().contains(newValue.lowercased()) }
        }
        .onAppear {
            // Fetch the first 10 users when the view appears
            searchResults = Array(currentUser.allUsers.prefix(10))

        }
        
    }
}

struct UserSearchResult : View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    var user : User
    
    
    var body: some View {
        HStack {
            
            ProfilePhotoOrInitials(profilePhoto: user.profilePhoto, fullName: user.name, radius: 40, fontSize: 24)
            
            Text(user.name)
                .font(.subheadline)
                .foregroundColor(.primary)
            
            Spacer()
            
            Button {
                
                let currentStatus = currentUser.friendsList[user.id]
                
                let isAdding = currentStatus == nil || currentStatus == ""
                let newOperation = isAdding ? "requested" : ""
                
                // Update the friend request status in Firestore
                currentUser.updateFriendRequest(userID: user.id, operation: newOperation)

            } label: {
                let status = currentUser.friendsList[user.id]
                
                if status == nil {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(.secondary)
                        Text("Request")
                            .foregroundColor(.secondary)
                    }
                    .font(.system(size: 12))

                    .padding(.vertical, 5)
                    .padding(.horizontal, 12)
                    .background(.indigo)
                    .cornerRadius(5)
                    
                } else if status == "requestSent" {
                    HStack {
                        Image(systemName: "clock.fill")
                            .foregroundColor(.secondary)
                        Text("Sent")
                            .foregroundColor(.secondary)
                    }
                    .font(.system(size: 12))
                    .padding(.vertical, 5)
                    .padding(.horizontal, 12)
                    .background(Color(.systemGray))
                    .cornerRadius(5)
                    
                } else if status == "accepted" {
                    HStack {
                        Image(systemName: "checkmark")
                            .foregroundColor(.secondary)
                        Text("Friends")
                            .foregroundColor(.secondary)
                    }
                    .font(.system(size: 12))
                    .padding(.vertical, 5)
                    .padding(.horizontal, 12)
                    .background(Color(.systemGray))
                    .cornerRadius(5)
                }

            }

        }
        .padding(.horizontal)
        .padding(.bottom)
        
    }
}

#Preview {
    SearchFriendsView()
        .environmentObject(CurrentUserViewModel())
}
