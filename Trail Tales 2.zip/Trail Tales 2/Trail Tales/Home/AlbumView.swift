//
//  AlbumView.swift
//  Trail Tales

import SwiftUI

struct AlbumView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var mapVM : MapViewModel
    @EnvironmentObject var currentUser : CurrentUserViewModel

    @State var showJournalEntry = false
    @State var showNewJournalEntry = false
    @State var showDeleteAlert = false
    @State var locationString = "Fetching location.."
    
    var album : Album
    @State var journalEntries : [JournalEntry] = []
    @State var journalToDisplay : JournalEntry?
    
    var body: some View {
        VStack {
            HStack {
                
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                }, label: {
                    Image(systemName: "chevron.left")
                })
                .foregroundColor(.primary)
                
                
                Text("\(locationString)")
                    .fontWeight(.bold)
                    .font(.headline)
                    .onAppear {
                        mapVM.reverseGeocodeLocation(latitude: album.lat, longitude: album.lng) { location in
                            if let locString = location {
                                locationString = locString
                            }
                        }
                    }
                
                Spacer()
                
                Button(action: {
                    showDeleteAlert = true
                    
                }, label: {
                    Image(systemName: "trash")
                        .foregroundColor(.primary)
                })
                .sheet(isPresented: $showNewJournalEntry, content: {
                    NewEntryView(album : album)
                })
                .alert(isPresented: $showDeleteAlert) {
                    Alert(
                        title: Text("Delete Album"),
                        message: Text("Are you sure you want to delete this album?"),
                        primaryButton: .cancel(),
                        secondaryButton: .destructive(Text("Delete"), action: {
                            currentUser.deleteAlbum(album)
                            self.presentationMode.wrappedValue.dismiss()
                        })
                    )
                }
            }
            .padding()
            .navigationTitle("")
            .navigationBarHidden(true)
            
            ScrollView {
                
                Button {
                    showNewJournalEntry = true

                } label: {
                    HStack {
                        Spacer()
                        Image(systemName: "plus")
                            .foregroundColor(.primary)
                        Spacer()
                    }
                    .frame(height: 80)
                    .background(.black.opacity(0.1))
                    .cornerRadius(10)
                    .padding()
                }
                
                ForEach(journalEntries, id :\.self) { journal in
                    Button(action: {
                        showJournalEntry = true
                        self.journalToDisplay = journal
                    }, label: {
                        JournalEntryPreview(journal : journal)
                    })
                }
            }

        }
        .sheet(isPresented: $showJournalEntry, content: {
            if let journal = journalToDisplay {
                JournalEntryView(albumID: album.id, journal : journal)
            }
        })
        .background(.regularMaterial)
        .onAppear {
            currentUser.fetchJournalEntries(for: album) { journals, error in
                if let journalData = journals {
                    self.journalEntries = journalData
                }
            }
        }
    }
}


struct JournalEntryPreview : View {
    
    var journal : JournalEntry

    
    var body: some View {
        VStack(spacing : 0) {
            
            if journal.image != "" {
                CachedAsyncImageView(urlString: journal.image)
                    .scaledToFill()
                    .frame(height : 200)
                    .cornerRadius(5)
            }

            
            HStack {
                Text(journal.content)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                    .padding()
                
                Spacer()
            }
            .foregroundColor(.primary)
            
            Divider()

            HStack {
                
                Image(systemName: "mappin")
                Text("\(journal.date.toCustomStringFormat())")
                
                Spacer()
                
                Image(systemName: "chevron.right")
            }
            .font(.system(size: 12))
            .foregroundColor(.secondary)
            .padding()


        }
        .padding(5)
        .background(.regularMaterial)
        .cornerRadius(5)
        .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x: 0, y :5)
        .padding(.horizontal)
        .padding(.bottom)


    }
}



//#Preview {
//    AlbumView()
//}
