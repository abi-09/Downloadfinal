//
//  MapViewModel.swift
//  Trail Tales


import SwiftUI
import Foundation
import CoreLocation
import MapKit



class MapViewModel : NSObject, ObservableObject, CLLocationManagerDelegate {
    
    private var locationManager = CLLocationManager()
    @Published var userLocation: CLLocation?
    @Published var locationString = ""
    
    override init() {
        super.init()
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    //Initialize to San Francisco
//    @Published var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), latitudinalMeters: 1000, longitudinalMeters: 1000)
    @Published var position: MapCameraPosition = .camera(.init(centerCoordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194), distance: 1000))
    @Published var defaultLocation = CLLocation(latitude: 37.7749, longitude:  -122.4194)
    
    func updateRegion(with location: CLLocation?) {
        if let coordinate = location?.coordinate {
            position  = .camera(.init(centerCoordinate: coordinate, distance: 20000))

        } else {
            position = .userLocation(fallback: .automatic)
        }
    }
    
    
    @Published var shouldRecenterMap = true

    func requestLocationAccess() {
        locationManager.requestWhenInUseAuthorization()
    }
    
    // Respond to authorization status changes
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
            case .notDetermined:
                // Request when-in-use authorization initially
                manager.requestWhenInUseAuthorization()
            case .restricted, .denied:
                // Handle case where user has denied or restricted location services
                break
            case .authorizedWhenInUse, .authorizedAlways:
                // Permission granted, start location updates
                manager.startUpdatingLocation()
            @unknown default:
                break
        }
    }
    
    
    // Handle location updates
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        DispatchQueue.main.async { [weak self] in
            self?.userLocation = location
        }
    }

    
    // Helper function for reverse geocoding
    func reverseGeocodeLocation(latitude: Double, longitude: Double, completion: @escaping (String?) -> Void) {
        let location = CLLocation(latitude: latitude, longitude: longitude)
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            guard let placemark = placemarks?.first else {
                completion(nil)
                return
            }
            if let city = placemark.locality, let state = placemark.administrativeArea {
                let locationString = "\(city), \(state)"
                completion(locationString)
            } else {
                completion(nil)
            }
        }
    }
}

