//
//  ProfileView.swift
//  Trail Tales


import SwiftUI

struct ProfileMenuView: View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @Binding var showProfile : Bool
    
    var body: some View {
        ZStack {
            HStack {
                Spacer()
                
                VStack {
                    
                    HStack {
                        Button(action: {
                            showProfile = false
                        }, label: {
                            Image(systemName: "xmark.circle")
                        })
                        .foregroundColor(.primary)

                        Spacer()
                    }
                    
                    
                    
                    Button(action: {
                        currentUser.showUserProfile = true
                    }, label: {
                        HStack {
                            ProfilePhotoOrInitials(profilePhoto: currentUser.user.profilePhoto, fullName: currentUser.user.name, radius: 50, fontSize: 24)
                                .id(currentUser.refreshID)

                            Text("Hi, \(getFirstName(currentUser.user.name))")
                                .font(.title2)
                                .foregroundColor(.primary)
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(.secondary)
                        }
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                        .padding(.top)
                    })
                    

                    
                    
                    Spacer()
                    
                    VStack (alignment: .leading){
                        HStack {
                            Text("Your friends")
                                .font(.title)
                            
                            Spacer()
                            
                            NavigationLink {
                                SearchFriendsView()
                            } label: {
                                Image(systemName: "plus.circle")
                                    .foregroundColor(.secondary)
                            }

                        }
                        .padding()
                        
                        ForEach(Array(currentUser.friendsList.keys), id: \.self) { friendID in
                            if let friend = currentUser.allUsers.first(where: { $0.id == friendID }) {
                                NavigationLink {
                                    UserProfileView(user: friend)
                                } label: {
                                    FriendPreview(user: friend, status: currentUser.friendsList[friendID] ?? "")
                                }
                            }
                        }

                        Spacer()
                    }
                    .background(.ultraThinMaterial)
                    .cornerRadius(10)
                    .padding(.top, 30)



                    
                }
                .padding()
                .background(.regularMaterial)
                .padding(.leading, 80)
            }
            
            CurrentUserProfileView()
                .trailingEdgeSheet(isPresented: currentUser.showUserProfile)
        }
    }
}

struct FriendPreview : View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    var user : User
    var status : String
    
    var body: some View {
        HStack {
            
            ProfilePhotoOrInitials(profilePhoto: user.profilePhoto, fullName: user.name, radius: 40, fontSize: 24)
            
            Text(user.name)
                .font(.subheadline)
                .foregroundColor(.primary)
            
            Spacer()
            
            if status == "requested" {
                
                Button(action: {
                    currentUser.acceptFriendRequest(userID: user.id)

                }, label: {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(.secondary)
                        Text("Accept")
                            .foregroundColor(.secondary)
                    }
                    .font(.system(size: 12))

                    .padding(.vertical, 5)
                    .padding(.horizontal, 12)
                    .background(.indigo)
                    .cornerRadius(5)
                })

            } else if status == "requestSent" {
                Button(action: {
                    currentUser.updateFriendRequest(userID: user.id, operation: "")

                }, label: {
                    HStack {
                        Image(systemName: "clock")
                            .foregroundColor(.secondary)
                        Text("Sent")
                            .foregroundColor(.secondary)
                    }
                    .font(.system(size: 12))
                    .padding(.vertical, 5)
                    .padding(.horizontal, 12)
                    .background(Color(.systemGray))
                    .cornerRadius(5)
                })
                
            } else {
                
                Image(systemName: "chevron.right")
                    .foregroundColor(.secondary)
            }
            
        }
        .padding(.horizontal)
        .padding(.bottom)
        
    }
}



//#Preview {
////    ProfileMenuView(showProfile : .constant(false))
//}
