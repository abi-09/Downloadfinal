//
//  NewEntryView.swift
//  Trail Tales


import SwiftUI
import CoreLocation


struct NewEntryView : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @EnvironmentObject var currentUser : CurrentUserViewModel
    @EnvironmentObject var mapVM : MapViewModel

    @State var journalEntry = "Start writing.."
    
    var album : Album
    
    @State var locationString = "Fetching location.."
    @State var imageURL : String?
    @State var isShowingImagePicker = false
    @State private var selectedImage: UIImage?

    @State var isPublic = true
    
    var body: some View {
        VStack {
            HStack(alignment : .top) {
                
                VStack(alignment : .leading, spacing : 8) {
                    Text("New Journal")
                        .foregroundColor(.primary)
                        .font(.headline)

                    HStack {
                        Image(systemName: "mappin")
                        Text("\(locationString)")
                    }
                    HStack {
                        Image(systemName: "clock")
                        Text("\(Date().toCustomStringFormat())")
                    }
                    
                    HStack {
                        Image(systemName: "globe.central.south.asia.fill")
                        Text(isPublic ? "Public" : "Private")
                        Spacer()
                        CustomToggleView(isOn: $isPublic, title: "")
                    }
                    .frame(width : 120)
                }
                .font(.system(size: 12))
                .foregroundColor(.secondary)
                
                Spacer()
                
                Button(action: {
                    currentUser.createJournalEntryForAlbum(album: album, image : imageURL ?? "", content : journalEntry, isPublic : isPublic)
                    self.presentationMode.wrappedValue.dismiss()
                }, label: {
                    Text("Create")
                })

            }
            .padding()
            
            Button(action: {
                isShowingImagePicker = true
            }, label: {
                
                if let urlString = imageURL {
                    CachedAsyncImageView(urlString: urlString)
                        .scaledToFill()
                        .frame(height : 200)
                        .cornerRadius(5)
                        .id(urlString)
                } else {
                    HStack {
                        Spacer()
                        Image(systemName: "photo.badge.plus")
                        Spacer()
                    }
                    .frame(height: 80)
                    .background(.black.opacity(0.1))
                    .cornerRadius(10)
                }

                
            })
            .padding(.horizontal)
            .sheet(isPresented: $isShowingImagePicker) {
                ImagePicker(image: $selectedImage)
                    .edgesIgnoringSafeArea(.bottom)
            }
            .onChange(of: isShowingImagePicker) { oldValue, newValue in
                if !newValue { // When the sheet is dismissed
                    if let selectedImage = selectedImage {
                        currentUser.uploadImage(selectedImage: selectedImage) { uploadedImageURL in
                            if let image = uploadedImageURL {
                                self.imageURL = image
                            }
                        }
                    }
                }
            }
            
            Divider()
                .padding(.top)
            
            TextEditor(text: $journalEntry)
                .padding(.horizontal)
                .foregroundColor(self.journalEntry == "Start writing.." ? .gray : .primary)
                .onAppear {
                    // remove the placeholder text when keyboard appears
                    NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: .main) { (noti) in
                        withAnimation {
                            if self.journalEntry == "Start writing.." {
                                self.journalEntry = ""
                            }
                        }
                    }
                    
                    // put back the placeholder text if the user dismisses the keyboard without adding any text
                    NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: .main) { (noti) in
                        withAnimation {
                            if self.journalEntry == "" {
                                self.journalEntry = "Start writing.."
                            }
                        }
                    }
                }

        }
        .onAppear(perform: {
            mapVM.reverseGeocodeLocation(latitude: album.lat, longitude: album.lng) { location in
                if let locString = location {
                    self.locationString = locString
                }
            }
        })
    }
}


struct CustomToggleView: View {
    @Binding var isOn: Bool
    var title : String

    var body: some View {
        Toggle("", isOn: $isOn)
            .toggleStyle(CustomToggleStyle())
    }
}


struct CustomToggleStyle: ToggleStyle {

    func makeBody(configuration: Configuration) -> some View {
        
        ZStack {
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(configuration.isOn ? .blue : .gray)
                    .shadow(.inner(color: .white.opacity(0.8), radius: 1, x: 0, y: -1))
                    .shadow(.inner(color: .black.opacity(0.3), radius: 2, x: 0, y: 2))
                )
                .frame(width: 40, height: 20)
                .overlay(
                    Circle()
                        .foregroundColor(.white)
                        .frame(height : 15)
                        .offset(x: configuration.isOn ? 10 : -10, y: 0)
                )
                .onTapGesture {
                    generateHapticFeedback()
                    withAnimation {
                        configuration.isOn.toggle()
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: configuration.isOn)

        }
    }
}



#Preview {
    NewEntryView(album : empty_album)
        .environmentObject(CurrentUserViewModel())
        .environmentObject(MapViewModel())
}
