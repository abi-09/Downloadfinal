//
//  CurrentUserViewModel.swift
//  Trail Tales


import SwiftUI
import Foundation
import Combine
import Firebase
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage
import FirebaseFirestoreSwift
import MapKit
import CoreLocation



struct Album : Identifiable, Hashable {
    var id : String
    var lat : Double
    var lng : Double
    var locationString : String
    var coverImage : String
    var dateCreated : Date
    var description : String
    var journalEntries : [JournalEntry]
}

struct JournalEntry : Identifiable, Hashable {
    var id : String
    var image : String
    var content : String
    var lat : Double
    var lng : Double
    var date : Date
    var locationString : String
    var isPublic : Bool
}


struct User : Identifiable, Hashable {
    var id : String
    var dateJoined : Date
    var profilePhoto : String
    var name : String
    var email : String
    var albums : [Album]
    
    func toDictionary() -> [String: Any] {
        let dictionary =  [
            "id": id,
            "dateJoined" : dateJoined,
            "profilePhoto": profilePhoto ,
            "name" : name,
            "email" : email,
            "albums" : []
        ] as [String : Any]
        
        return dictionary
    }
}


//Static Globals
let database = Firestore.firestore()
let empty_user = User(id: "", dateJoined : Date(), profilePhoto: "", name: "", email: "", albums: [])
let empty_album = Album(id: UUID().uuidString, lat: 0, lng: 0, locationString: "", coverImage: "", dateCreated: Date(), description: "", journalEntries: [])


class CurrentUserViewModel: ObservableObject {
    let delegate = UIApplication.shared.delegate as! AppDelegate
    let db = Firestore.firestore()
    
    //Navigation
    @Published var isAppLoading = true
    @Published var showSideMenu = false
    @Published var showUserProfile = false
    @Published var showSearchMenu = false
    @Published var showNewEntry = false
    
    @Published var selectedAlbum : Album?
    @Published var journalToDisplay = JournalEntry(id: "", image: "", content: "", lat: 0.0, lng: 0.0, date: Date(), locationString: "", isPublic: false)

    //Refresh ID to force view updates (Photo selection..)
    @Published var refreshID = UUID()

    @Published var allUsers: [User] = []
    @Published var user : User = empty_user
    @Published var friends : [User] = []
    @Published var friendsList : [String : String] = [:] //Stores the array of user ID's
    @Published var friendRequests : [String] = []
    
    //Handles real-time authentication changes to conditionally display login/home views
    var didChange = PassthroughSubject<CurrentUserViewModel, Never>()
    
    @Published var currentUserID: String = "" {
        didSet {
            didChange.send(self)
        }
    }

    
    var handle: AuthStateDidChangeListenerHandle?
    
    func listen () {
        handle = Auth.auth().addStateDidChangeListener { (auth, user) in
            if let user = user {

                
                print("User Authenticated: \(user.uid)")
                self.currentUserID = user.uid
                self.getUserInfo(userID: user.uid)
                
            } else {
                print("No user available, loading initial view")
                self.currentUserID = ""
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    withAnimation {
                        self.isAppLoading = false
                    }
                }
            }
        }
    }


    
    //Fetch initial data once, add listeners for appropriate conditions
    func getUserInfo(userID: String) {
        let userInfo = database.collection("users").document(userID)
        
        userInfo.getDocument { documentSnapshot, error in
            guard let document = documentSnapshot else {
                print("Error fetching document: \(error!)")
                return
            }
            guard document.exists else {
                //This case should never exist unless there's a major issue - sign the user out to restart flow
                print("User document does not exist in database, terminating authentication")
                self.signOut()
                
                return
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                withAnimation {
                    self.isAppLoading = false
                }
            }
            
            self.fetchAllUsers() // See definition
            
            self.listenForCoreUserChanges(userID: document.documentID) 
            self.listenToUserAlbums()
        }
    }
    
    func listenForCoreUserChanges(userID: String) {
        database.collection("users").document(userID).addSnapshotListener { [self] snapshot, error in
            guard let document = snapshot else {
              print("Error fetching document: \(error!)")
              return
            }
            
            let userData = document.data()
            
            updateFriendsList(document: document)
            
            self.user = createUserFromData(userID: userID, userData: userData ?? [:] )
            self.fetchAlbums() //Call this everytime the user's data changes
            
        }
    }
    
    func listenToUserAlbums() {
        let db = Firestore.firestore()
        
        db.collection("users").document(self.currentUserID)
            .collection("albums")
            .addSnapshotListener { [weak self] snapshot, error in
                guard let self = self else { return }
                
                if let error = error {
                    print("Error listening to user's albums: \(error.localizedDescription)")
                    return
                }
                
                guard let snapshot = snapshot else {
                    print("No data found for user's albums")
                    return
                }
                
                var userAlbums: [Album] = []
                
                for document in snapshot.documents {
                    let data = document.data()
                    
                    var dateCreated = Date()
                    if let timestamp = data["dateCreated"] as? Timestamp {
                        dateCreated = timestamp.dateValue()
                    }
                    
                    // Create the album object
                    let album = Album(id: document.documentID,
                                      lat: data["lat"] as? Double ?? 0.0,
                                      lng: data["lng"] as? Double ?? 0.0,
                                      locationString: data["locationString"] as? String ?? "No location available",
                                      coverImage: data["coverImage"] as? String ?? "",
                                      dateCreated: dateCreated,
                                      description : data["description"] as? String ?? "",
                                      journalEntries: [])
                    
                    if album.lat != 0.0 && album.lng != 0.0 { //Only display albums with valid locations
                        
                        userAlbums.append(album)

                    }
                }
                
                // Update the albums published variable with the new data
                self.user.albums = userAlbums
                print("Done fetching users albums")
        }
    }
    
    func fetchAlbums() {
        database.collection("users").document(self.currentUserID)
            .collection("albums")
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error listening to user's albums: \(error.localizedDescription)")
                    return
                }
                
                guard let snapshot = snapshot else {
                    print("No data found for user's albums")
                    return
                }
                
                var userAlbums: [Album] = []
                
                for document in snapshot.documents {
                    let data = document.data()
                    
                    var dateCreated = Date()
                    if let timestamp = data["dateCreated"] as? Timestamp {
                        dateCreated = timestamp.dateValue()
                    }
                    
                    // Create the album object
                    let album = Album(id: document.documentID,
                                      lat: data["lat"] as? Double ?? 0.0,
                                      lng: data["lng"] as? Double ?? 0.0,
                                      locationString: data["locationString"] as? String ?? "No location available",
                                      coverImage: data["coverImage"] as? String ?? "",
                                      dateCreated: dateCreated,
                                      description : data["description"] as? String ?? "",
                                      journalEntries: [])
                    
                    if album.lat != 0.0 && album.lng != 0.0 { //Only display albums with valid locations
                        
                        userAlbums.append(album)

                    }
                }
                
                // Update the albums published variable with the new data
                self.user.albums = userAlbums
                print("Done fetching users albums")
        }
    }
    
    func fetchJournalEntries(for album: Album, completion: @escaping ([JournalEntry]?, Error?) -> Void) {
        let db = Firestore.firestore()
        
        db.collection("users").document(self.currentUserID)
            .collection("albums").document(album.id)
            .collection("journalEntries")
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching journal entries: \(error.localizedDescription)")
                    completion(nil, error)
                    return
                }
                
                guard let snapshot = snapshot else {
                    print("No data found for journal entries")
                    completion([], nil)
                    return
                }
                
                var journalEntries: [JournalEntry] = []
                
                for document in snapshot.documents {
                    let data = document.data()
                    
                    // Extracting data from Firestore document snapshot
                    guard let image = data["image"] as? String,
                          let content = data["content"] as? String,
                          let lat = data["lat"] as? Double,
                          let lng = data["lng"] as? Double,
                          let dateTimestamp = data["date"] as? Timestamp,
                          let locationString = data["locationString"] as? String else {
                        print("Error extracting journal entry data from document")
                        continue
                    }
                    
                    let journalEntry = JournalEntry(id: document.documentID,
                                                    image: image,
                                                    content: content,
                                                    lat: lat,
                                                    lng: lng,
                                                    date: dateTimestamp.dateValue(),
                                                    locationString: locationString,
                                                    isPublic : data["isPublic"] as? Bool ?? false
                    )
                    
                    journalEntries.append(journalEntry)
                }
                
                completion(journalEntries, nil)
            }
    }
    
    //fetch all users from database
    func fetchAllUsers() {
        let db = Firestore.firestore()
        
        db.collection("users").getDocuments { querySnapshot, error in
            guard let documents = querySnapshot?.documents else {
                print("Error fetching users: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            // Clear allUsers before appending new users
            self.allUsers = []
            
            for document in documents {
                let userData = document.data()
                let userID = document.documentID
                let user = self.createUserFromData(userID: userID, userData: userData)
                self.allUsers.append(user)
            }
            
            print("All users fetched successfully")
            
            self.friends = self.allUsers.filter { user in
                // Check if the user ID exists in the friendsList and the status is "accepted"
                return self.friendsList[user.id] == "accepted"
            }
        }
    }
    
    //fetch users public albums
    func fetchPublicUserAlbums(of userID: String, completion: @escaping ([Album]) -> Void) {
        let db = Firestore.firestore()
        
        if userID.isEmpty {
            print("Cannot fetch albums for nonexistent user")
        } else {
            db.collection("users").document(userID)
                .collection("albums")
                .getDocuments { snapshot, error in
                    if let error = error {
                        print("Error fetching user's albums: \(error.localizedDescription)")
                        completion([])
                        return
                    }

                    guard let snapshot = snapshot else {
                        print("No data found for user's albums")
                        completion([])
                        return
                    }

                    let group = DispatchGroup()
                    var publicUserAlbums: [Album] = []

                    for document in snapshot.documents {
                        let data = document.data()
                        
                        var dateCreated = Date()
                        if let timestamp = data["dateCreated"] as? Timestamp {
                            dateCreated = timestamp.dateValue()
                        }
                        
                        var album = Album(id: document.documentID,
                                          lat: data["lat"] as? Double ?? 0.0,
                                          lng: data["lng"] as? Double ?? 0.0,
                                          locationString: data["locationString"] as? String ?? "No location available",
                                          coverImage: data["coverImage"] as? String ?? "",
                                          dateCreated: dateCreated,
                                          description: data["description"] as? String ?? "",
                                          journalEntries: [])

                        group.enter()
                        self.fetchPublicJournalEntries(for: album, ownerID: userID) { journalEntries in
                            album.journalEntries = journalEntries
                            print("Fetched journal entries for album, count : \(album.journalEntries.count)")
                            publicUserAlbums.append(album)
                            group.leave()
                        }
                    }

                    group.notify(queue: .main) {
                        completion(publicUserAlbums)
                    }
                }
        }
        
    }
    
    //fetch users public posts
    func fetchPublicJournalEntries(for album: Album, ownerID: String, completion: @escaping ([JournalEntry]) -> Void) {
        let db = Firestore.firestore()

        db.collection("users").document(ownerID)
            .collection("albums")
            .document(album.id)
            .collection("journalEntries")
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching public journal entries: \(error.localizedDescription)")
                    completion([])
                    return
                }

                guard let snapshot = snapshot else {
                    print("No data found for public journal entries")
                    completion([])
                    return
                }

                var publicJournalEntries: [JournalEntry] = []

                for document in snapshot.documents {
                    let data = document.data()
                    
                    guard let image = data["image"] as? String,
                          let content = data["content"] as? String,
                          let lat = data["lat"] as? Double,
                          let lng = data["lng"] as? Double,
                          let dateTimestamp = data["date"] as? Timestamp,
                          let locationString = data["locationString"] as? String else {
                        print("Error extracting journal entry data from document")
                        continue
                    }

                    let journalEntry = JournalEntry(id: document.documentID,
                                                    image: image,
                                                    content: content,
                                                    lat: lat,
                                                    lng: lng,
                                                    date: dateTimestamp.dateValue(),
                                                    locationString: locationString,
                                                    isPublic: data["isPublic"] as? Bool ?? false)

                    if journalEntry.isPublic {
                        publicJournalEntries.append(journalEntry)

                    }
                }

                completion(publicJournalEntries)
            }
    }

    
    // Helper function for reverse geocoding
    func reverseGeocodeLocation(latitude: Double, longitude: Double, completion: @escaping (String?) -> Void) {
        let location = CLLocation(latitude: latitude, longitude: longitude) // Create a CLLocation object with the provided latitude and longitude
        // Use CLGeocoder to reverse geocode the CLLocation object
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            // Check if there are any placemarks returned; if not, return nil via the completion handler
            guard let placemark = placemarks?.first else {
                completion(nil)
                return
            }
            if let city = placemark.locality, let state = placemark.administrativeArea { //obtains location of CLlocation object to attach to pin
                let locationString = "\(city), \(state)"
                completion(locationString)
            } else {
                completion(nil)
            }
        }
    }
    
    //check closest album location
    func closestAlbum(to location: CLLocation, minDistanceMiles : Double) -> (Album?, Bool) {
        // Set "nearby" threshold to 100 miles, this can be adjusted
        let minimumDistanceThreshold: CLLocationDistance = minDistanceMiles * 1609.34
        
        var isExistingAlbum = false //check if there is an exisitng album
        var closestAlbum: Album?
        var closestDistance: CLLocationDistance = Double.infinity // setting threshold to check closest album
        
        for album in self.user.albums {
            let albumLocation = CLLocation(latitude: album.lat, longitude: album.lng) //set location for album
            let distance = location.distance(from: albumLocation)
            
            if distance < closestDistance {
                closestDistance = distance
                closestAlbum = album
                isExistingAlbum = true
            }
        }
        
        // Check if closestAlbum is nil or the closest distance exceeds the threshold
        if closestAlbum == nil || closestDistance > minimumDistanceThreshold {
            // Create a new empty album with the user's location
            print("Exceeds threshold")
            closestAlbum = Album(id: "", lat: location.coordinate.latitude, lng: location.coordinate.longitude, locationString: "", coverImage: "", dateCreated: Date(), description: "", journalEntries: [])
            isExistingAlbum = false
        }
        
        return (closestAlbum, isExistingAlbum)
    }
    
    //creating journal entries for albums
    func createJournalEntryForAlbum(album: Album, image: String, content: String, isPublic : Bool) {
        let journalData: [String: Any] = [
            "image": image,
            "content": content,
            "lat": album.lat, //get latitude
            "lng": album.lng, //get longtitude
            "date": Timestamp(date: Date()), // set timestamp
            "locationString": "", //fetch location
            "isPublic" : isPublic // set post to public
        ]
        
        // Check if the album ID is empty, indicating it doesn't exist yet
        if album.id.isEmpty || album.id == "" {
            // If the album doesn't exist, generate a random document ID for the new album
            let newAlbumID = generateRandomString(length: 8)
            reverseGeocodeLocation(latitude: album.lat, longitude: album.lng) { locationString in
                var newAlbum = [
                    "lat": album.lat,
                    "lng": album.lng,
                    "locationString" : "",
                    "coverImage": image, //Initialize cover photo to first journal entry
                    "dateCreated": Timestamp(date: Date()),
                    "description" : content
                ] as [String : Any]
                
                if let geocodedString = locationString {
                    newAlbum["locationString"] = geocodedString
                }
                
                // Set the new album document with the generated ID
                database.collection("users").document(self.currentUserID)
                    .collection("albums").document(newAlbumID).setData(newAlbum) { error in
                        if let error = error {
                            print("Error creating album document: \(error)")
                            return
                        }
                        
                        // Add the journal entry to the newly created album
                        database.collection("users").document(self.currentUserID)
                            .collection("albums").document(newAlbumID)
                            .collection("journalEntries").addDocument(data: journalData) { error in
                                if let error = error {
                                    print("Error adding document: \(error)")
                                } else {
                                    print("Document added successfully")
                                }
                        }
                }
            }


        } else {
            // If the album already exists, proceed to add the journal entry
            db.collection("users").document(self.currentUserID)
                .collection("albums").document(album.id)
                .collection("journalEntries").addDocument(data: journalData) { error in
                    if let error = error {
                        print("Error adding document: \(error)")
                    } else {
                        print("Document added successfully")
                    }
            }
        }
    }
    
    
    func deleteAlbum(_ album: Album) {
        let db = Firestore.firestore()
        
        if album.id.isEmpty {
            print("This shouldn't happen, album data: \(album)")
            return
        }

        let albumRef = db.collection("users").document(self.currentUserID)
            .collection("albums").document(album.id)

        // First, delete all journal entries in the subcollection
        deleteDocumentsInSubcollection(parentDocument: albumRef, subcollection: "journalEntries") { [weak self] error in
            if let error = error {
                print("Error deleting journal entries: \(error.localizedDescription)")
            } else {
                print("Journal entries deleted successfully")
                
                // Now delete the album document
                albumRef.delete { error in
                    if let error = error {
                        print("Error deleting album: \(error.localizedDescription)")
                    } else {
                        print("Album deleted successfully")
                        self?.user.albums.removeAll { $0.id == album.id }
                    }
                }
            }
        }
    }
    
    // Helper function to delete all documents in a subcollection
    func deleteDocumentsInSubcollection(parentDocument: DocumentReference, subcollection: String, completion: @escaping (Error?) -> Void) {
        let subcollectionRef = parentDocument.collection(subcollection)
        
        subcollectionRef.getDocuments { (snapshot, error) in
            guard let snapshot = snapshot else {
                completion(error)
                return
            }
            
            guard snapshot.documents.count > 0 else {
                completion(nil) 
                return
            }
            
            let group = DispatchGroup()
            var lastError: Error?
            
            for document in snapshot.documents {
                group.enter()
                document.reference.delete { error in
                    if let error = error {
                        lastError = error
                    }
                    group.leave()
                }
            }
            
            group.notify(queue: .main) {
                completion(lastError)
            }
        }
    }
    
    
    func deleteJournalEntry(albumID: String, journalID: String, completion: @escaping (Bool, Error?) -> Void) {
        let journalEntryRef = database.collection("users").document(self.currentUserID)
                .collection("albums").document(albumID)
                .collection("journalEntries").document(journalID)
            
            journalEntryRef.delete { error in
                if let error = error {
                    print("Error removing document: \(error)")
                    completion(false, error)
                } else {
                    print("Journal entry successfully removed ID: \(journalID)")
                    self.checkAndDeleteAlbum(albumID: albumID) { success, error in
                        completion(success, error)
                    }
                }
            }
        }

    func checkAndDeleteAlbum(albumID: String, completion: @escaping (Bool, Error?) -> Void) {
        let albumRef = database.collection("users").document(currentUserID)
            .collection("albums").document(albumID)
            .collection("journalEntries")
        
        albumRef.getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching documents: \(error)")
                completion(false, error)
            } else {
                if snapshot!.documents.isEmpty {
                    let albumRef = database.collection("users").document(self.currentUserID)
                        .collection("albums").document(albumID)
                    
                    albumRef.delete { error in
                        if let error = error {
                            print("Error removing album: \(error)")
                            completion(false, error)
                        } else {
                            print("Album successfully removed: \(albumID)")
                            completion(true, nil)
                        }
                    }
                } else {
                    // If there are still journal entries, we don't delete the album
                    completion(true, nil)
                }
            }
        }
    }
    
    func updateJournalEntry(albumID: String, journalID: String, newImageURL: String, newContent: String, isPublic: Bool, completion: @escaping (Bool, Error?) -> Void) {
        // Prepare the data to update
        let updatedData: [String: Any] = [
            "image": newImageURL,
            "content": newContent,
            "isPublic": isPublic
        ]

        // Path to the specific journal entry
        let journalRef = database.collection("users").document(currentUserID)
            .collection("albums").document(albumID)
            .collection("journalEntries").document(journalID)

        // Update the journal entry document
        journalRef.updateData(updatedData) { error in
            if let error = error {
                print("Error updating document: \(error)")
                completion(false, error)
            } else {
                print("Document successfully updated")
                completion(true, nil)
            }
        }
    }
    
    


    private func updateFriendsList(document: DocumentSnapshot) {
        var newFriendsList: [String: String] = [:]

        if let friendsDict = document.data()?["friends"] as? [String: String] {
            newFriendsList = friendsDict
        }

        // Update the published variable
        DispatchQueue.main.async {
            self.friendsList = newFriendsList
        }
    }
    
    func updateFriendRequest(userID: String, operation: String) {
        let db = Firestore.firestore()

        // Document references for both the current user and the target user
        let currentUserDoc = db.collection("users").document(currentUserID)
        let friendUserDoc = db.collection("users").document(userID)

        // Update the friend's document to reflect the current user's request
        let friendFieldPath = "friends.\(currentUserID)"
        if operation.isEmpty {
            
            let batch = db.batch()
            batch.updateData([friendFieldPath: FieldValue.delete()], forDocument: friendUserDoc)
            batch.updateData(["friends.\(userID)": FieldValue.delete()], forDocument: currentUserDoc)
            batch.commit { error in
                if let error = error {
                    print("Error removing friend from both sides: \(error.localizedDescription)")
                } else {
                    print("Friend removed successfully from both sides")
                }
            }
        } else {
            let batch = db.batch()
            batch.updateData([friendFieldPath: operation], forDocument: friendUserDoc)
            batch.updateData(["friends.\(userID)": "requestSent"], forDocument: currentUserDoc)
            batch.commit { error in
                if let error = error {
                    print("Error updating friends list on both sides: \(error.localizedDescription)")
                } else {
                    print("Friends list updated successfully on both sides")
                }
            }
        }
    }
    
    func acceptFriendRequest(userID: String) {
        let db = Firestore.firestore()

        // Document references for both the current user and the target user
        let currentUserDoc = db.collection("users").document(currentUserID)
        let friendUserDoc = db.collection("users").document(userID)

        let friendFieldPath = "friends.\(currentUserID)"
        let batch = db.batch()
        batch.updateData([friendFieldPath: "accepted"], forDocument: friendUserDoc)
        batch.updateData(["friends.\(userID)": "accepted"], forDocument: currentUserDoc)
        batch.commit { error in
            if let error = error {
                print("Error updating friends list on both sides: \(error.localizedDescription)")
            } else {
                print("Friends list updated successfully on both sides")
            }
        }
    }
    
    
    //Helper function to create users from fetched data
    func createUserFromData(userID : String, userData : [String : Any]) -> User {
        var dateJoined = Date()
        if let timestamp = userData["dateJoined"] as? Timestamp { //Firestore has custom date objects, need to convert
            dateJoined = timestamp.dateValue()
        }

        let user = User(id: userID,
                        dateJoined: dateJoined,
                        profilePhoto: userData["profilePhoto"] as? String ?? "",
                        name: userData["name"] as? String ?? "",
                        email: userData["email"] as? String ?? "",
                        albums : [])
        
        return user
    }
    
    
    func updateUserWithCompletion(data: [String: Any], completion: @escaping (Result<Void, Error>) -> Void) {
        let userInfo = database.collection("users").document(self.currentUserID)
        userInfo.updateData(data) { err in
            if let err = err {
                print("Error updating document: \(err)")
                completion(.failure(err))
            } else {
                print("User data successfully updated : \(data)")
                completion(.success(()))
            }
        }
    }
    
    func updateUser(data: [String: Any]) {
        let userInfo = database.collection("users").document(self.currentUserID)
        userInfo.updateData(data) { err in
            if let err = err {
                print("Error updating document: \(err)")
            } else {
                print("User data successfully updated: \(data)")
            }
        }
    }
    
    // Function to upload image to Firebase Storage
    func uploadProfileImage(_ image: UIImage, completion: @escaping (Result<URL, Error>) -> Void) {
        let imageData = image.jpegData(compressionQuality: 0.4)
        let randomID = UUID()
        let storageRef = Storage.storage().reference().child("profileImages/\(randomID).jpg")

        storageRef.putData(imageData!, metadata: nil) { metadata, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            storageRef.downloadURL { url, error in
                if let error = error {
                    completion(.failure(error))
                } else if let url = url {
                    completion(.success(url))
                }
            }
        }
    }
    
    // Function to update user's profile photo URL in Firestore
    func updateUserProfilePhotoURL(_ url: URL, completion: @escaping (Result<Void, Error>) -> Void) {
        let db = Firestore.firestore()

        if self.currentUserID != "" {
            //User is logged in
            db.collection("users").document(self.currentUserID).updateData(["profilePhoto": url.absoluteString]) { error in
                if let error = error {
                    completion(.failure(error))
                } else {
                    print("Successfully updated profile photo")
                    completion(.success(()))
                    self.refreshID = UUID()
                }
            }
            
        } else {
            //User is creating their account
            self.user.profilePhoto = url.absoluteString
            self.refreshID = UUID()
            print(self.user.profilePhoto)

        }

    }
    
    
    
    func uploadImage(selectedImage: UIImage, completion: @escaping (String?) -> Void) {
        guard let imageData = selectedImage.jpegData(compressionQuality: 0.4) else {
            completion(nil) // Handle the case where image data couldn't be prepared
            return
        }
        
        let fileName = UUID().uuidString + ".jpg"
        let storageRef = Storage.storage().reference().child("journalImages/\(fileName)")
        
        storageRef.putData(imageData, metadata: nil) { metadata, error in
            guard let _ = metadata, error == nil else {
                completion(nil)
                return
            }
            
            storageRef.downloadURL { url, error in
                guard let downloadURL = url, error == nil else {
                    completion(nil)
                    return
                }
                
                completion(downloadURL.absoluteString) // Successfully uploaded and URL retrieved
            }
        }
    }
    
    
    func createUser(email: String, password: String, userData : User, completion: @escaping (Bool, String) -> Void) {
        
        //Create auth user
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Error creating auth user: \(error.localizedDescription)")
                completion(false, error.localizedDescription)
            } else if let authResult = authResult {
                                
                
                // Create a new user
                var newUser = userData
                newUser.id = authResult.user.uid

                // Convert user to dictionary
                let data = newUser.toDictionary()
                print("Creating new user with data : \(data)")
                
                // Add user to Firestore
                database.collection("users").document(authResult.user.uid).setData(data) { error in
                    if let error = error {
                        print("Error writing user to Firestore: \(error.localizedDescription)")
                        completion(false, error.localizedDescription)
                    } else {
                        // Success
                        print("User successfully written to Firestore")
                                                
                        completion(true, "")
                    }
                }
            }
        }
    }
    
    
    func signOut () {
        do {
            try Auth.auth().signOut()
            print("Successfully signed out user")
            resetCurrentUserVM()
            
        } catch {
            print("Error signing out user")
        }
    }
    
    
    func resetCurrentUserVM() {
        self.user = empty_user
        
        isAppLoading = true
        showSideMenu = true
        showUserProfile = true
        showSearchMenu = true
        showNewEntry = true

        selectedAlbum = empty_album
        journalToDisplay = JournalEntry(id: "", image: "", content: "", lat: 0.0, lng: 0.0, date: Date(), locationString: "", isPublic: false)

        refreshID = UUID()

        self.allUsers = []
        self.user = empty_user
        self.friends = []
        self.friendsList = [:]
        self.friendRequests = []

    }
}

