//
//  Loginview.swift
//  Trail Tales

import SwiftUI
import FirebaseAuth
import Firebase



struct LoginView: View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    
    @State var email : String = ""
    @State var password : String = ""
    @State var showPasswordReset = false
    
    @State var emailErrorMessage = ""
    @State var passwordErrorMessage = ""
    
    @State var showErrorMessageModal = false
    @State var errorTitle = "Something went wrong"
    @State var errorMessage = "There seems to be an issue. Please try again"
        
    func formatErrorMessage(errorDescription : String) {
        switch errorDescription {
            
        case "The password is invalid or the user does not have a password." :
            errorTitle = "Invalid Password"
            errorMessage = "Either your password or email is incorrect, please try again."
            
        case "The email address is badly formatted." :
            errorTitle = "Invalid Email"
            errorMessage = "There's an issue with your email. Please ensure it's formatted correctly"
            
        case "There is no user record corresponding to this identifier. The user may have been deleted." :
            errorTitle = "No Account Found"
            errorMessage = "There's no account matching that information. Please check your email and try again"
            
        default :
            errorTitle = "Something went wrong"
            errorMessage = "There seems to be an issue. Please try again "
        }
    }
// login and user authentication
    var body: some View {
        
        ZStack {
            VStack {
                Spacer()
                
                VStack(spacing : 16) {
                    
                    
                    AccountCreationField(text: $email, title: "Email address", placeholder: "email@example.com", isRequired: false)
                    
                    PasswordCreationField(text: $password, title: "Password", placeholder: "***************", isRequired: false)
                    
                    Button(action: {
                        print("tapped")
                        //Reset error states on tap
                        emailErrorMessage = ""
                        passwordErrorMessage = ""
                        
                        //Check for new error states
                        if email.isEmpty {
                            withAnimation {
                                errorTitle = "Empty Email"
                                errorMessage = "Please enter your email address"
                                showErrorMessageModal = true

                            }
                        } else if password.isEmpty {
                            withAnimation {
                                errorTitle = "Empty Password"
                                errorMessage = "Please enter your password"
                                showErrorMessageModal = true
                            }
                        } else {
                            
                            Auth.auth().signIn(withEmail: email, password: password){ (authResult, error) in
                                if let error = error {
                                    // Handle the error (e.g., incorrect OTP)
                                    print("Error in authentication: \(error.localizedDescription)")
            
                                    withAnimation {
                                        showErrorMessageModal = true
                                        print( error)
                                        formatErrorMessage(errorDescription: error.localizedDescription)
                                    }
                                    
                                    return
                                }
        
                                print("Successfully authenticated user: \(Auth.auth().currentUser?.uid ?? "")")
        
                            }
                        }
                    }, label: {
                        HStack {
                            Spacer()
                            Text("Login")
                                .font(.system(size: 17))
                              .foregroundColor(.primary)
                            Spacer()

                        }
                        .frame(height : 50)
                        .background(.indigo)
                        .cornerRadius(8)
                    })
                    
                    Divider()

                    
                    
                    NavigationLink {
                        AccountCreation()
                    } label: {
                        HStack {
                            Spacer()
                            Text("Create an account")
                                .foregroundColor(.primary)
                            Spacer()
                        }
                        .frame(height : 50)
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 4)
                            .inset(by: 0.75)
                            .stroke(Color(.systemGray), lineWidth: 1.5)

                        )
                    }

                    
                    Button {
                        showPasswordReset.toggle()
                    } label: {
                        Text("Forgot your password?")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 20)
                    .sheet(isPresented: $showPasswordReset, content: {
                        PasswordResetSheet(showPasswordReset: $showPasswordReset)
                            .presentationDetents([.height(380)])
                            .edgesIgnoringSafeArea(.bottom)

                    })

                }
                .padding()
                .background(.thinMaterial)
                .cornerRadius(8)
                .shadow(radius: 5, x: 0, y: 5)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                
                Spacer()

            }

            .background(.regularMaterial)
            .overlay(
                Color.black.opacity(showErrorMessageModal ? 0.5 : 0)
                    .edgesIgnoringSafeArea(.all)
                    .onTapGesture {
                        withAnimation {
                            showErrorMessageModal = false
                        }
                    }
            )
            
            
            
            ErrorMessageModal(showErrorMessageModal: $showErrorMessageModal, title: errorTitle, message: errorMessage)
                .centerGrowingModal(isPresented: showErrorMessageModal)
        }
        .onTapGesture {
            hideKeyboard()
        }
        .edgesIgnoringSafeArea(.all)
        .background(.white)

    }
}

// resetting password
struct PasswordResetSheet : View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    @Binding var showPasswordReset : Bool
    
    @State var email = ""
    @State var emailError = false
    @State var emailSent = false
    
    @Environment(\.openURL) var openURL

    var body: some View {
        VStack(spacing : 24) {
            Rectangle()
              .foregroundColor(.clear)
              .frame(width: 70, height: 5)
              .background(Color(red: 0.84, green: 0.84, blue: 0.84))
              .cornerRadius(100)
              .padding(.top)

            
            if emailSent {
                VStack(alignment: .center, spacing : 0) {
                    
                    Text("Successfully sent!")
                      .font(
                        Font.custom("Source Sans Pro", size: 18)
                          .weight(.bold)
                      )
                      .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.13))
                    
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 32))
                        .padding(.vertical, 10)
                    
                    // Paragraph - 14
                    Text("Check your email for instructions. If you need still need help please contact support at:")
                      .font(Font.custom("Nunito Sans", size: 14))
                      .multilineTextAlignment(.center)
                      .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.13))
                      .frame(height : 50)
                      .padding(.horizontal)
                      .lineLimit(3)

                    
                    Button(action: {
                        // Safely attempt to construct the URL and open it
                        guard let mailURL = URL(string: "mailto:test@example.com") else {
                            return
                        }
                        openURL(mailURL)
                    }) {
                        Text("text@example.com")
                            .font(.system(size: 14, weight: .medium))
                    }
                    .padding(.vertical, 30)
                    .padding(.bottom, 10)
                    
                    
                    Button(action: {
                        self.presentationMode.wrappedValue.dismiss()
                    }, label: {
                        ButtonLabelDark(text: "Done")
                    })

                }
                .transition(.opacity)
                .animation(.easeInOut, value: emailSent)
                
                
            } else {
                // H3 Heading - 18 - Nunito Sans
                VStack(spacing : 4) {
                    Text("Reset your password")
                      .font(
                        Font.custom("Source Sans Pro", size: 18)
                          .weight(.bold)
                      )
                      .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.13))
                    
                    // Paragraph - 14
                    Text("Enter your email and we'll send you a link to reset your password")
                      .font(Font.custom("Nunito Sans", size: 14))
                      .multilineTextAlignment(.center)
                      .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.13))
                      .frame(maxWidth: .infinity, alignment: .top)
                      .frame(height : 50)
                }

                TextField("", text: $email, prompt: Text(verbatim: "samcooke@gmail.com")
                    .font(.custom("Nunito Sans", size: 14))
                    .foregroundColor(Color("placeholder")))
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .font(.custom("Nunito Sans", size: 14))
                    .padding(.leading, 16)
                    .padding(.vertical, 13)
                    .foregroundColor(.black)
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                        .inset(by: 0.5)
                        .stroke(Color(red: 0.07, green: 0.07, blue: 0.07).opacity(0.2), lineWidth: 1)
                    )
                    .onChange(of: email) { oldValue, newValue in
                        self.email = newValue.lowercased()
                    }
                
                Button(action: {
                    if email == "" {
                        emailError = true
                    } else {
                        Auth.auth().sendPasswordReset(withEmail: email) { error in

                            if let error = error {
                                print(error.localizedDescription)
                            }
                            
                            withAnimation {
                                emailSent = true
                                print("Password reset email sent to : \(email)")
                            }
                        }
                    }
                }, label: {
                    HStack(alignment: .center, spacing: 0) {
                        Text("Send")
                          .font(Font.custom("Nunito Sans", size: 17))
                          .foregroundColor(.white)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 14)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(Color(red: 0.13, green: 0.13, blue: 0.13))
                    .cornerRadius(4)
                })
                .disabled(email == "")

                
                
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                }, label: {
                    HStack(alignment: .center, spacing: 0) {
                        Text("Cancel")
                          .font(.custom("Nunito Sans", size: 18))
                          .fontWeight(.semibold)
                          .underline()
                          .multilineTextAlignment(.center)
                          .foregroundColor(Color(red: 0.13, green: 0.13, blue: 0.13))
                    }
                    .padding(.horizontal, 21)
                    .padding(.vertical, 13)
                    .frame(width: 312, alignment: .center)
                    .background(.white)
                    .cornerRadius(25)
                })
                
            }
            

            Spacer()
        }
        .padding(24)
        .background(.white)
        .cornerRadius(16, corners: [.topLeft, .topRight])
    }
}




#Preview {
    LoginView()
        .environmentObject(CurrentUserViewModel())
}
