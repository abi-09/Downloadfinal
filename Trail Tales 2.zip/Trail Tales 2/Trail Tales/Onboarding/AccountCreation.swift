//
//  AccountCreation.swift
//  Trail Tales


import SwiftUI


struct AccountCreation: View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    @State var password = ""
    @State var confirmPassword = ""
    
    @State var showErrorMessageModal = false
    @State var errorTitle = "Something went wrong"
    @State var errorMessage = "There seems to be an issue. Please try again or contact support if the problem continues"
    
    @State private var isLoading: Bool = false
    
    @State var navigateToVerification = false
    
    private func createAccount() {//creating account logic
        withAnimation {
            //Reset errors every attempt
            let user = currentUser.user
            
            if user.name.isEmpty || user.email.isEmpty  { // checks if user inputted email
                errorTitle = "Error"
                errorMessage = "Please enter all required fields"
                showErrorMessageModal = true

            } else if password.isEmpty {//check if password is chosen
                errorTitle = "Error"
                errorMessage = "Please choose a password"
                showErrorMessageModal = true

            } else if confirmPassword.isEmpty {//retype password for conformation
                errorTitle = "Error"
                errorMessage = "Please confirm your password"
                showErrorMessageModal = true

            } else if password != confirmPassword { //check passwords match
                errorTitle = "Error"
                errorMessage = "Your passwords don't match"
                showErrorMessageModal = true

            } else {
                isLoading = true
                
                currentUser.createUser(email: currentUser.user.email, password: password, userData: currentUser.user) { success, errorMessage in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { // Ensure minimum 2 seconds loading
                        isLoading = false
                        
                        if success {
                            self.presentationMode.wrappedValue.dismiss()
                        } else {
                            showErrorMessageModal = true
                            formatErrorMessage(errorDescription: errorMessage)
                        }
                    }
                }
            }
        }
    }
    
    //error messages regarding the error detewcted by the system
    func formatErrorMessage(errorDescription : String) {
        switch errorDescription {
        //email error
        case "The email address is already in use by another account." :
            errorTitle = "Email in use"
            errorMessage = "This email is already being used by another account. If this is you, please try logging in instead"
        
        case "The email address is badly formatted." :
            errorTitle = "Invalid Email"
            errorMessage = "There's an issue with your email. Please ensure it's formatted correctly"
         
        //password errors
        case "The password must be 6 characters long or more." :
            errorTitle = "Insecure Password"
            errorMessage = "Please choose a password with 6 characters or more."
            
        default :
            errorTitle = "Something went wrong"
            errorMessage = "There seems to be an issue. Please try again or contact support if the problem continues"
        }
    }
    
    var body: some View {
        
        ZStack {
            VStack(spacing : 0) {
                
                BackNavHeaderWithTitle(title: "Account Creation")

                VStack(spacing : 0) {
                    
                    HStack {
                        //attaches profile picture to account
                        ProfilePhotoButton()
                        AccountCreationField(text: $currentUser.user.name, title: "Name", placeholder: "Jane")

                    }
                     
                    //creates account ans store information of user in database
                    Group {
                        
                        AccountCreationField(text: $currentUser.user.email, title: "Email address", placeholder: "example@gmail.com")
                        PasswordCreationField(text: $password, title: "Password", placeholder: "***************", isRequired: true)
                        PasswordCreationField(text: $confirmPassword, title: "Confirm Password", placeholder: "***************", isRequired: true)
                    }

                    Divider()
                        .padding(.vertical, 24)
                        .foregroundColor(.secondary)

                    
                    VStack(spacing : 16) {
                        
                        Button(action: {
                            self.createAccount()
                        }, label: {
                            HStack {
                                Spacer()
                                Text("Create account")
                                    .foregroundColor(.primary)
                                Spacer()

                            }
                            .frame(height : 50)
                            .background(.indigo)

                            .cornerRadius(8)
                        })

                    }
                    
                }
                .padding()
                .background(.thinMaterial)
                .cornerRadius(8)
                .shadow(radius: 5, x: 0, y: 5)
                .padding(.horizontal, 24)
                .padding(.top, 24)
                Spacer()
  
            }
            .background(.regularMaterial)
            .onTapGesture {
                hideKeyboard()
            }
            .overlay {
                if isLoading {
                    LoadingView()
                        .edgesIgnoringSafeArea(.all)
                } else {
                    Color.black.opacity(showErrorMessageModal ? 0.5 : 0)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            withAnimation {
                                showErrorMessageModal = false
                            }
                        }
                }
            }
            
            VStack {
                Spacer()
                ErrorMessageModal(showErrorMessageModal: $showErrorMessageModal, title: errorTitle, message: errorMessage)
                    .centerGrowingModal(isPresented: showErrorMessageModal)
                Spacer()
            }
        }
    }
}


struct AccountCreationField : View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    @Binding var text : String
    var title : String
    var placeholder : String
    var isRequired : Bool = true
    
    var showError : Bool = false
    var errorMessage : String = "Error"
    
    var body: some View {
        VStack(alignment : .leading) {
            HStack(spacing : 2) {
                Text(title)
                  .fontWeight(.semibold)
                  .foregroundColor(.primary)
            }
            
            TextField("", text: $text, prompt: Text(verbatim: placeholder)
                .font(.custom("Nunito Sans", size: 14))
                .foregroundColor(.secondary))
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .padding(.leading, 16)
                .padding(.vertical, 13)
                .foregroundColor(.primary)
                .overlay(
                    RoundedRectangle(cornerRadius: 4)
                        .inset(by: 0.5)
                        .stroke(Color(red: 0.07, green: 0.07, blue: 0.07).opacity(0.2), lineWidth: 1)
                )
                .background(.thinMaterial)
                .cornerRadius(4)
            
        }
        .padding(.top, 16)
        
    }
}

struct LoadingView: View {
    @State private var isAnimating = false

    
    var body: some View {
        ZStack {
            Color.black.opacity(0.4).edgesIgnoringSafeArea(.all)
            
            VStack {
                ProgressView()
                
            }
            .cornerRadius(15)
        }
    }
}

struct PasswordCreationField: View {
    @Binding var text: String
    var title: String
    var placeholder: String
    var isRequired : Bool
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack(spacing: 2) {
                Text(title)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
            }
            
            SecureField(placeholder, text: $text)
                .textInputAutocapitalization(.never)
                .disableAutocorrection(true)
                .padding(.leading, 16)
                .padding(.vertical, 13)
                .foregroundColor(.primary)
                .overlay(
                    RoundedRectangle(cornerRadius: 4)
                        .inset(by: 0.5)
                        .stroke(Color(red: 0.07, green: 0.07, blue: 0.07).opacity(0.2), lineWidth: 1)
                )
                .background(.thinMaterial)
                .cornerRadius(4)
        }
        .padding(.top, 16)
    }
}

struct PasswordSecurityIndicator: View {
    var password: String
    
    private var strength: (filledCount: Int, color: Color, label: String) {
        if password.isEmpty {
            return (0, Color.gray, "Enter password")
        }
        
        let length = password.count
        let hasUppercase = password.range(of: "[A-Z]", options: .regularExpression) != nil
        let hasNumber = password.range(of: "\\d", options: .regularExpression) != nil
        let hasSymbol = password.range(of: "[!@#$%^&*(),.?\":{}|<>]", options: .regularExpression) != nil

        switch (length, hasUppercase, hasNumber, hasSymbol) {
        case (8..., true, true, true):
            return (4, Color(.green), "Strong") // Define "extraStrongGreen" in your assets
        case (8..., true, true, _):
            return (3, Color(.teal), "Good")
        case (8..., _, _, _):
            return (2, Color.yellow, "Moderate")
        default:
            return (1, Color(.red), "Weak")
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 4) {
                ForEach(0..<4) { index in
                    Rectangle()
                        .fill(index < strength.filledCount ? strength.color : Color.gray.opacity(0.5))
                        .frame(width: .infinity, height: 4)
                }
            }
            .padding(.vertical, 8)
            
            HStack {
                Spacer()
                
                Text(strength.label)
                    .font(.custom("Nunito Sans", size: 12).weight(.semibold))
                    .kerning(0.048)
                    .multilineTextAlignment(.trailing)
                    .foregroundColor(strength.color)
                    .frame(maxWidth: .infinity, minHeight: 19, maxHeight: 19, alignment: .topTrailing)
            }
        }
    }
}



#Preview {
    AccountCreation()
        .environmentObject(CurrentUserViewModel())
}
