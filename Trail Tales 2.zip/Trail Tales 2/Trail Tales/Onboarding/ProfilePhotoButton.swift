//
//  ProfilePhotoButton.swift
//  Trail Tales


import SwiftUI
import UIKit


struct ProfilePhotoButton : View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    
    
    @State var showImagePicker: Bool = false
    @State var selectedImage: UIImage?
    
    var radius : CGFloat = 96
    var fontSize : CGFloat = 40
    
    private func handleImageSelection(_ image: UIImage) {
         currentUser.uploadProfileImage(image) { result in
             switch result {
             case .success(let url):
                 currentUser.updateUserProfilePhotoURL(url) { result in
                     switch result {
                     case .success():
                         print("New Profile Image : \(currentUser.user.profilePhoto)")
                         print("User profile updated successfully")
                     case .failure(let error):
                         print("Error updating user profile: \(error.localizedDescription)")
                     }
                 }

             case .failure(let error):
                 print("Error uploading image: \(error.localizedDescription)")
             }
         }
     }
    
    
    var body: some View {
        Button {
            self.showImagePicker = true

        } label: {
            if currentUser.user.profilePhoto != "" {
                ProfilePhotoOrInitials(profilePhoto: currentUser.user.profilePhoto, fullName: "", radius: radius, fontSize: fontSize)
            } else {
                ZStack {
                    Circle()
                        .frame(width : 80, height : 80)
                        .clipShape(Circle())
                        .foregroundColor(Color(.systemGray))

                    Image(systemName: "person.fill")
                        .font(.system(size: 24))
                        .foregroundColor(.primary)
                }
                .padding(.trailing)
            }

        }
        .sheet(isPresented: $showImagePicker, onDismiss: {
            if let selectedImage = self.selectedImage {
                handleImageSelection(selectedImage)
            }
        }) {
            ImagePicker(image: self.$selectedImage)
                .edgesIgnoringSafeArea(.bottom)
        }
        .id(currentUser.refreshID)

    }
}





struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.presentationMode) var presentationMode  // Corrected this line

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        // No need to implement anything here for now
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }

            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}
