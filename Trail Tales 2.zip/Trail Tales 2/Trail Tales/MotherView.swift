//
//  ContentView.swift
//  Trail Tales


import SwiftUI

enum Tab: Int, Identifiable, CaseIterable, Comparable {
    static func < (lhs: Tab, rhs: Tab) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
    
    case albums, map
    
    internal var id: Int { rawValue }
    
    var icon: String {
        switch self {
        case .albums:
            return "photo.stack"
        case .map:
            return "map.fill"

        }
    }
}

struct MotherView: View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    @EnvironmentObject var mapVM : MapViewModel

    @State var tabShowing = Tab.albums

    var body: some View {
        
        NavigationStack {

            if currentUser.currentUserID.isEmpty || currentUser.currentUserID == "" {
                LoginView()
                
            } else {
                VStack(spacing : 0) {
                    switch tabShowing {
                    case .albums:
                        AlbumsListView()
                    case .map:
                        HomeView()
                    }
                    
                    Divider()
                    
                    TabsLayoutView(selectedTab: $tabShowing)
                }
                .onAppear {
                    mapVM.requestLocationAccess()
                }
            }
        }
        .onAppear {
            currentUser.listen() //Entry point to the app, attaches the authentication listener and views update based on the current user's ID
        }
    }
}



fileprivate struct TabsLayoutView: View {
    @EnvironmentObject var currentUser : CurrentUserViewModel
    @EnvironmentObject var mapVM : MapViewModel

    @Binding var selectedTab: Tab
    @Namespace var namespace
    
    var body: some View {
        
        VStack {
            HStack {
                Spacer(minLength: 0)
                
                TabButton(tab: .albums, selectedTab: $selectedTab, namespace: namespace)
                    .frame(width: 40, height: 40, alignment: .center)
                    .padding(.top, 10)

                Spacer(minLength: 0)
                
                Button(action: {
                    currentUser.selectedAlbum = nil
                    currentUser.showNewEntry = true
                }) {
                    Image(systemName: "plus")
                        .foregroundColor(.white)
                        .font(.system(size: 24, weight: .bold))
                        .frame(width: 60, height: 60) // Adjust the size as needed
                        .background(.blue)
                        .clipShape(Circle())
                        .shadow(radius: 10)
                }
                .offset ( y : -30)
                .sheet(isPresented: $currentUser.showNewEntry, content: { //All of this mess is required because MapReaders don't permit long press gestures..
                    if let userHasSelectedLocation = currentUser.selectedAlbum {
                        NewEntryView(album : userHasSelectedLocation)
                    } else {
                        let (nearbyAlbum, _) = currentUser.closestAlbum(to: mapVM.userLocation ?? mapVM.defaultLocation, minDistanceMiles: 100)
                        if let album = nearbyAlbum {
                            NewEntryView(album : album)
                        }
                    }
                })
                
                Spacer(minLength: 0)

                
                TabButton(tab: .map, selectedTab: $selectedTab, namespace: namespace)
                    .frame(width: 40, height: 40, alignment: .center)
                    .padding(.top, 10)
                
                Spacer(minLength: 0)
                

            }
            .frame(height: 60, alignment: .center)
            .background(.regularMaterial)
        }
    }
    
    private struct TabButton: View {
        let tab: Tab
        @Binding var selectedTab: Tab
        var namespace: Namespace.ID
        
        var body: some View {
            Button {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.9, blendDuration: 0.6)) {
                    selectedTab = tab
                }
            } label: {
                ZStack {
                    if isSelected {
                        RoundedRectangle(cornerRadius: 13, style: .continuous)
                            .fill(
                                Color.blue
                            )
                            .overlay(content: {
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(width : 40, height : 40)
                            })
                            .matchedGeometryEffect(id: "Selected Tab", in: namespace)
                    }
                    
                    Image(systemName: tab.icon)
                        .foregroundColor(selectedTab == tab ? .primary : .secondary )
                        .font(.system(size: 20, weight: .semibold, design: .rounded))
                        .scaleEffect(isSelected ? 1 : 0.9)
                        .animation(isSelected ? .spring(response: 0.5, dampingFraction: 0.3, blendDuration: 1) : .spring(), value: selectedTab)
                }
            }
        }
        
        private var isSelected: Bool {
            selectedTab == tab
        }
    }
    
    
    
}


#Preview {
    MotherView()
        .environmentObject(CurrentUserViewModel())
        .environmentObject(MapViewModel())

}
