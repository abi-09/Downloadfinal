//
//  Functions.swift
//  Trail Tales


import Foundation
import UIKit


func getFirstName(_ fullName: String) -> String {
    let nameParts = fullName.split(separator: " ").map(String.init)
    guard let firstName = nameParts.first else { return fullName }

    return firstName
}

func getFirstAndLastInitial(_ fullName: String) -> String {
    let nameParts = fullName.split(separator: " ").map(String.init)
    guard let firstName = nameParts.first else { return fullName }

    var formattedName = firstName

    if nameParts.count > 1, let lastNameInitial = nameParts.last?.first {
        formattedName += " \(lastNameInitial)."
    }

    return formattedName
}

func getInitials(fullName : String) -> String {
    let names = fullName.split(separator: " ")

    switch names.count {
    case 0:
        return ""
    case 1:
        // Only one name provided
        return String(names.first!.prefix(1))
    default:
        // Two or more names provided, get the first and last name initials
        let firstInitial = names.first!.prefix(1)
        let lastInitial = names.last!.prefix(1)
        return "\(firstInitial)\(lastInitial)"
    }
}

func generateRandomString(length: Int) -> String {
    let lettersAndDigits = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return String((0..<length).compactMap{ _ in lettersAndDigits.randomElement() })
}


func generateHapticFeedback() {
    let generator = UIImpactFeedbackGenerator(style: .medium)
    generator.prepare()
    generator.impactOccurred()
}
