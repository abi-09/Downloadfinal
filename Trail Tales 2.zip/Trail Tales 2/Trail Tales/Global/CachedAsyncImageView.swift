//
//  CachedAsyncImageView.swift
//  Trail Tales


import Foundation
import UIKit
import SwiftUI
import Combine

class ImageCache {
    static let shared = NSCache<NSString, UIImage>()

    static func getImage(forKey key: String) -> UIImage? {
        return shared.object(forKey: key as NSString)
    }

    static func setImage(_ image: UIImage, forKey key: String) {
        shared.setObject(image, forKey: key as NSString)
    }
}

class CachedImageLoader: ObservableObject {
    @Published var image: UIImage?
    private var urlString: String
    private var cancellable: AnyCancellable?

    init(urlString: String) {
        self.urlString = urlString
    }

    func load() {
        if let cachedImage = ImageCache.getImage(forKey: urlString) {
            image = cachedImage
            return
        }

        guard let url = URL(string: urlString) else {
            return
        }

        cancellable = URLSession.shared.dataTaskPublisher(for: url)
            .map { UIImage(data: $0.data) }
            .replaceError(with: nil)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                if let image = $0 {
                    ImageCache.setImage(image, forKey: self?.urlString ?? "")
                    self?.image = image
                }
            }
    }

    func cancel() {
        cancellable?.cancel()
    }
}

struct CachedAsyncImageView: View {
    @StateObject private var loader: CachedImageLoader
    init(urlString: String) {
        _loader = StateObject(wrappedValue: CachedImageLoader(urlString: urlString))
    }

    var body: some View {
        Group {
            if let image = loader.image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                ProgressView()
            }
        }
        .onAppear(perform: loader.load)
        .onDisappear(perform: loader.cancel)
    }
}



struct ProfilePhotoOrInitials : View {
    
    let profilePhoto : String
    let fullName : String
    let radius : CGFloat
    let fontSize : CGFloat
    
    var body: some View {
        if ( profilePhoto == "") {
            
            if fullName != "" {
                Text(getInitials(fullName: fullName))
                    .font(.system(size: fontSize))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black.opacity(0.5))
                    .frame(width: radius, height: radius)
                    .background(Color(red: 0.95, green: 0.95, blue: 0.95))
                    .cornerRadius(100)
                    .shadow(radius: 10, x:0, y:5)


                
            } else {
                Image(systemName: "person.fill")
                    .font(.system( size: fontSize))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.black.opacity(0.5))
                    .frame(width: radius, height: radius)
                    .background(Color(red: 0.95, green: 0.95, blue: 0.95))
                    .cornerRadius(100)
                    .shadow(radius: 10, x:0, y:5)

            }
            
        } else {
            CachedAsyncImageView(urlString: profilePhoto)
                .scaledToFill()
                .frame(width: radius, height: radius)
                .clipShape(Circle())
                .shadow(radius: 10, x:0, y:5)


        }
    }
}
