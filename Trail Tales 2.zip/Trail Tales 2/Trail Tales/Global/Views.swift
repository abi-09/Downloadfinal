//
//  Views.swift
//  Trail Tales


import SwiftUI




struct ButtonLabelDark : View {
    var text : String
    
    
    var body: some View {
        HStack(alignment: .center, spacing: 4) {
            Text(text)
              .font(Font.custom("Nunito Sans", size: 17))
              .foregroundColor(.primary)

        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .center)
        .background(Color(red: 0.13, green: 0.13, blue: 0.13))
        .cornerRadius(4)
    }
}

struct ButtonLabelUnderline : View {
    var text : String
    
    
    var body: some View {
        HStack(alignment: .center, spacing: 4) {
            Text(text)
              .font(.custom("Nunito Sans", size: 18))
              .fontWeight(.semibold)
              .underline()
              .foregroundColor(.primary)
        }
        .padding(.horizontal, 21)
        .padding(.vertical, 13)
        .frame( alignment: .center)
        .cornerRadius(25)
    }
}



struct BackNavHeaderWithTitle : View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    var title : String
    
    
    var body: some View {
        ZStack {
            HStack(spacing : 0) {
                Button {
                    self.presentationMode.wrappedValue.dismiss()
                } label: {
                    Image(systemName : "chevron.left")
                        .font(.system(size: 17, weight : .semibold))
                        .foregroundColor(.primary)
                        .padding(.trailing, 3)
                    
                    Text("Back")
                        .font(.subheadline)
                        .foregroundColor(.primary)
                }
                .navigationTitle("")
                .navigationBarHidden(true)


                
                Spacer()
            }
            
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)
        }
        .frame(height : 44)
        .padding(.horizontal)
        .overlay(
            Rectangle()
                .frame(height: 0.333)
                .foregroundColor(Color(.black.opacity(0.3))),
            alignment: .bottom
        )
    }
}
