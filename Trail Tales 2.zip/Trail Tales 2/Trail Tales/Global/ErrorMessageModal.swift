//
//  ErrorMessageModal.swift
//  Trail Tales



import SwiftUI

struct ErrorMessageModal : View {
    @Binding var showErrorMessageModal : Bool
    
    var title : String
    var message : String
    
    
    var body: some View {
        VStack(spacing : 0) {
            HStack {
                Button {
                    showErrorMessageModal = false

                } label: {
                    Image(systemName : "xmark")
                        .foregroundColor(Color(hex : "#202020"))
                        .opacity(0.7)
                        .frame(width: 30, height: 30)
                }
                Spacer()
                
                Text(title)
                    .font(.system(size: 18, weight : .bold))
                    .foregroundColor(Color(hex : "#202020"))
                    .offset(x : -10)


                Spacer()

            }
            .padding()
            
            Text(verbatim: message)
                .font(.system(size: 14, weight : .medium))
                .foregroundColor(Color(hex : "#202020"))
                .padding(.horizontal)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            

            
            HStack(spacing : 15) {
                
                
                Button {
                    withAnimation {
                        showErrorMessageModal = false
                    }
                } label: {
                    ButtonLabelDark(text: "Ok")

                }

            }
            .padding(.horizontal, 30)
            .padding(.vertical, 20)
        

        }
        .frame(width : 350)
        .background(Color(.white))
        .cornerRadius(15)
    }
}

#Preview {
    ZStack {

        Color(.white)
            .overlay {
                Color(.black.opacity(0.7))
                    .edgesIgnoringSafeArea(.all)

            }
        ErrorMessageModal(showErrorMessageModal: .constant(true), title: "Something went wrong", message: "There seems to be an issue. Please try again or contact support if the problem continues \n\n www.website.com")
    }

}
